#ifndef __main__
#define __main__

#include "main.h"

// Tests for rect intersection.
bool rectIntersectsRectI(
	int aX1, int aY1, int aX2, int aY2, 
	int bX1, int bY1, int bX2, int bY2
) {
	return (
		((aX1 < bX2) && (aY1 < bY2) && (aX2 > bX1) && (aY2 > bY1)) ||
		((bX1 < aX2) && (bY1 < aY2) && (bX2 > aX1) && (bY2 > aY1))
	);
}

// Tests for rect intersection.
bool rectIntersectsRectF(
	float aX1, float aY1, float aX2, float aY2, 
	float bX1, float bY1, float bX2, float bY2
) {
	return (
		((aX1 < bX2) && (aY1 < bY2) && (aX2 > bX1) && (aY2 > bY1)) ||
		((bX1 < aX2) && (bY1 < aY2) && (bX2 > aX1) && (bY2 > aY1))
	);
}

// include cpp files ;)
#include "game.cpp"
#include "titlescr.cpp"
#include "hud.cpp"


// code
int main(void)	{
	Game game = Game();

	Level level = {
		0,
		const_cast<unsigned int*>
		(DEFAULT_LEVELS_LEVEL_0_BRICK_TYPES)
	};

	Level levels[1] = { level };

	LevelSet defaultLevelSet = {
		"Dess1", "Dessimat0r",
		BRICK_FIELD_BRICK_ROWS,
		BRICK_FIELD_BRICK_COLS,
		levels, 1
	};

	// init palib
	PA_Init();
	PA_InitVBL();

	//PA_SplashBlue();

	game = Game(&defaultLevelSet);

	while(1) {
		if (game.inited) game.update();
		PA_WaitForVBL();
	}
	
	return 0;
}

#endif
