#ifndef __titlescr_h__
#define __titlescr_h__

#include "main.h"

#endif
