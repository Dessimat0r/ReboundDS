#ifndef __main_h__
#define __main_h__

#ifndef NOMINMAX
  #ifndef max
    #define MAX(a,b) (((a) > (b)) ? (a) : (b))
  #endif
  #ifndef min
    #define MIN(a,b) (((a) < (b)) ? (a) : (b))
  #endif
#endif  /* NOMINMAX */

#include <PA9.h>

// Converted using PAGfx
#include "gfx/all_gfx.h"

const unsigned int
	BAT_WIDTH = 3U,
	BAT_HEIGHT = 20U,
	BRICK_WIDTH = 8U,
	BRICK_HEIGHT = 12U,
	PLAY_FIELD_X = 10U,
	PLAY_FIELD_Y = 10U,
	PLAY_FIELD_WIDTH = 230U,
	PLAY_FIELD_HEIGHT = 168U,
	PLAY_FIELD_X2 = PLAY_FIELD_X + (PLAY_FIELD_WIDTH - 1),
	PLAY_FIELD_Y2 = PLAY_FIELD_Y + (PLAY_FIELD_HEIGHT - 1),
	BRICK_FIELD_X = 40U,
	BRICK_FIELD_WIDTH = (PLAY_FIELD_WIDTH - 1) - BRICK_FIELD_X,
	BRICK_FIELD_BRICK_COLS = 25U,
	BRICK_FIELD_BRICK_ROWS = 14U,
	BAT_X = PLAY_FIELD_X,
	BAT_AREA_Y = PLAY_FIELD_Y + 2U,
	BAT_AREA_HEIGHT = BAT_AREA_Y + PLAY_FIELD_HEIGHT - 1 - 4,
	BALL_DIAMETER = 3,
	BALL_C_OFFSET = 2
;

bool rectIntersectsRectI(
	int aX1, int aY1, int aX2, int aY2, 
	int bX1, int bY1, int bX2, int bY2
);

bool rectIntersectsRectF(
	float aX1, float aY1, float aX2, float aY2, 
	float bX1, float bY1, float bX2, float bY2
);

#include "game.h"
#include "level.h"
#include "titlescr.h"

#endif
