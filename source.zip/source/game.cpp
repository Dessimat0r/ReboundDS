#ifdef __main__
#include "game.h"

Game::Game() :
	inited(false)
{}

Game::Game(LevelSet *_pLevelSet) :
	inited(true),
	pLevelSet(_pLevelSet),
	currLevelNo(0)
{
	pCurrLevel = &pLevelSet->paLevel[currLevelNo];
	
	Bat &bat = bats[0];
	Ball &ball = balls[0];

	bat.topY = 40;
	bat.bottomY = bat.topY + (BAT_HEIGHT - 1);

	ball.x = 40;
	ball.y = 40;
	ball.vX = 1;
	ball.vY = 1;

	hud.pGame = this;

	initGfx();
}

void Game::initGfx() {
	PA_ResetSpriteSys();

	PA_Init16bitBg(0, 0);
	PA_Init16bitBg(1, 0);

	unsigned char *_bat_Sprite =
		const_cast<unsigned char*>(bat_Sprite)
	;

	batGfx = PA_CreateGfx(
		1,
		_bat_Sprite,
		OBJ_SIZE_8X32,
		1
	);

	unsigned char *_brick1_Sprite =
		const_cast<unsigned char*>(brick1_Sprite)
	;

	brick1Gfx = PA_CreateGfx(
		1,
		_brick1_Sprite,
		OBJ_SIZE_8X16,
		1
	);

	unsigned char *_ball_Sprite =
		const_cast<unsigned char*>(ball_Sprite)
	;

	ballGfx = PA_CreateGfx(
		1,
		_ball_Sprite,
		OBJ_SIZE_8X8,
		1
	);
	
	// draw playfield lines
	PA_Draw16bitLineEx(
		1,
		PLAY_FIELD_X, PLAY_FIELD_Y - 2,
		PLAY_FIELD_X2, PLAY_FIELD_Y - 2,
		PA_RGB(31, 31, 31),
		2U
	);

	PA_Draw16bitLineEx(
		1,
		PLAY_FIELD_X, PLAY_FIELD_Y2 + 1,
		PLAY_FIELD_X2, PLAY_FIELD_Y2 + 1,
		PA_RGB(31, 31, 31),
		2U
	);

	PA_Draw16bitLineEx(
		1,
		PLAY_FIELD_X2 + 1, PLAY_FIELD_Y - 2,
		PLAY_FIELD_X2 + 1, PLAY_FIELD_Y2 + 1,
		PA_RGB(31, 31, 31),
		2U
	);
	/*
	// draw playfield lines
	PA_Draw16bitLine(
		1,
		PLAY_FIELD_X, PLAY_FIELD_Y,
		PLAY_FIELD_X2, PLAY_FIELD_Y,
		PA_RGB(31, 0, 31)
	);

	PA_Draw16bitLine(
		1,
		PLAY_FIELD_X, PLAY_FIELD_Y2,
		PLAY_FIELD_X2, PLAY_FIELD_Y2,
		PA_RGB(31, 0, 31)
	);

	PA_Draw16bitLine(
		1,
		PLAY_FIELD_X2, PLAY_FIELD_Y,
		PLAY_FIELD_X2, PLAY_FIELD_Y2,
		PA_RGB(31, 0, 31)
	);
	*/

	//PA_LoadSpritePal(0, 0, (void*)pal1_Pal); // Load the sprite palette
	PA_LoadSpritePal(1, 0, (void*)pal1_Pal); // Load the sprite palette

	PA_SetBgColor(0, PA_RGB(0, 0, 0));
	PA_SetBgColor(1, PA_RGB(0, 0, 0));
	
	PA_CreateSpriteFromGfx( 
		1, // 1 = top screen
		0, // sprite number (0 to 127)
		batGfx, // sprite gfx
		OBJ_SIZE_8X32, // sprite size
		1, // 1 = 256 colours
		0, // palette number
		BAT_X, // x
		BAT_AREA_Y + bats[0].topY // y
	);

	Ball &ball = balls[0];

	PA_CreateSpriteFromGfx( 
		1, // 1 = top screen
		1, // sprite number (0 to 127)
		ballGfx, // sprite gfx
		OBJ_SIZE_8X8, // sprite size
		1, // 1 = 256 colours
		0, // palette number
		PLAY_FIELD_X + (int)ball.x, // x
		PLAY_FIELD_Y + (int)ball.y // y
	);

	Level &level = *pCurrLevel;
	int i = 2;
	
	// create sprites for bricks
	for (unsigned int row = 0; row < BRICK_FIELD_BRICK_ROWS; row++) {
		for (unsigned int col = 0; col < BRICK_FIELD_BRICK_COLS; col++) {
			unsigned int &type =
				level.paBrickTypes[(row * BRICK_FIELD_BRICK_COLS) + col]
			;
			if (type != BRICK_TYPE_NONE) {
				printf("%d\n", i);
				PA_CreateSpriteFromGfx(
					1, // 1 = top screen
					i++, // sprite number (0 to 127)
					brick1Gfx, // sprite gfx
					OBJ_SIZE_8X16, // sprite size
					1, // 1 = 256 colours
					0, // palette number
					BRICK_FIELD_X + (BRICK_WIDTH * col), // x
					PLAY_FIELD_Y + (BRICK_HEIGHT * row) // y
				);
			}
		}
	}
	
	// Inits the sprite draw mode,
	// necessary for the pixel-perfect touch detection
	PA_InitAllSpriteDraw();
}

Game::~Game() {
	inited = false;
}

void Game::updateBats() {
	if (Stylus.Held || Stylus.Newpress) {
		Bat &bat = bats[0];

		// all this needs fixing
		
		int yborder = 10;
		int totalyborder = yborder * 2;
		int yrange = SCREEN_HEIGHT - totalyborder;

		int stylusYNew = MAX(
			yborder,
			MIN(
				Stylus.Y,
				SCREEN_HEIGHT - yborder
			)
		);

		int batcy = (int)(((
			(float)(stylusYNew / (float)yrange)
		)) * (float)BAT_AREA_HEIGHT);

		batcy = MAX(
			(BAT_HEIGHT / 2), // fix this
			MIN(
				batcy,
				(BAT_AREA_HEIGHT - 1) - (BAT_HEIGHT / 2) - 1 - 8 // and this!
			)
		);

		int baty = batcy - ((BAT_HEIGHT / 2) - 1);
		
		bat.topY = baty;
		bat.bottomY = bat.topY + (BAT_HEIGHT - 1);
		
		// update bat sprite
		PA_SetSpriteY(1, 0, BAT_AREA_Y + bat.topY);
	}
}

void Game::updateBalls() {
	updateBall(0);
}

void Game::updateBall(unsigned int num, unsigned int iter) {
	Ball &ball = balls[num];

	float newX = ball.x + ball.vX;
	float newY = ball.y + ball.vY;
	float newX2 = ball.x + BALL_DIAMETER;
	float newY2 = ball.y + BALL_DIAMETER;

	bool perish = false;

	// test for intersections
	bool intersectingWWalls =
	testIntersectionWalls(
		(int)newX, (int)newY,
		(int)newX2, (int)newY2,
		perish
	);

	if (!intersectingWWalls) {
		int brickX;
		int brickY;
		unsigned int brickNo;

		bool intersectingWBricks =
		testIntersectionBricks(
			(int)newX, (int)newY,
			(int)newX2, (int)newY2,
			brickX, brickY,
			brickNo
		);

		if (!intersectingWBricks) {
			ball.x = newX;
			ball.y = newY;

			PA_SetSpriteXY(
				1,
				1,
				PLAY_FIELD_X + (int)newX,
				PLAY_FIELD_Y + (int)newY
			);
		}
	} else {
		if (!perish) {
			ball.vX = -ball.vX;
			ball.vY = -ball.vY;
			
			if (++iter < 2) updateBall(0, iter);
		}
	}
}

bool Game::testIntersectionWalls(
	int x1, int y1, int x2, int y2,
	bool &perish
) {
	perish = false;
	if (!rectIntersectsRectI(
		x1, y1, x2, y2,
		0, 0,
		PLAY_FIELD_WIDTH - 1,
		PLAY_FIELD_HEIGHT - 1
	)) {
		if (y1 < PLAY_FIELD_Y) {
			perish = true;
		}
		return true;
	};
	return false;
}

bool Game::testIntersectionBricks(
	int x1, int y1, int x2, int y2,
	int &brickX, int &brickY,
	unsigned int &brickNo
) {
	return false;
}

void Game::update() {
	// update game
	updateBats();
	updateBalls();
}

#endif
