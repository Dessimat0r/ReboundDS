#ifdef __main__
#include "hud.h"

HUD::HUD() {}
HUD::~HUD() {}

#endif
