#ifndef __game_h__
#define __game_h__

#include "hud.h"
#include "level.h"

struct Level;
struct LevelSet;

struct Player {
	u8 id;
};

struct Ball {
	float x, y;
	float vX, vY;
};

struct Bat {
	// top y, bottom y is cached from top y
	int topY, bottomY;
};

class Game {
	public:
		Game();
		Game(LevelSet *_pLevelSet);
		~Game();

		void initGfx();
		void update();

		void updateBats();
		void updateBalls();
		void updateBall(unsigned int num, unsigned int iter = 0);

		bool testIntersectionWalls(
			int x1, int y1, int x2, int y2,
			bool &perish
		);

		bool testIntersectionBricks(
			int x1, int y1, int x2, int y2,
			int &brickX, int &brickY,
			unsigned int &brickNo
		);

		bool inited;
		LevelSet *pLevelSet;
		unsigned int currLevelNo;
		Level *pCurrLevel;
		
		HUD hud;
		Ball balls[1];
		Player players[1];
		Bat bats[1];

		u16 batGfx, ballGfx, brick1Gfx;
};

#endif
